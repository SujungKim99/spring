package dw.jdbcproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JdbcprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(JdbcprojectApplication.class, args);
	}

}
