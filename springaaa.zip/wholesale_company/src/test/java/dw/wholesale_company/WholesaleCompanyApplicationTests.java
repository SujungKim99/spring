package dw.wholesale_company;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WholesaleCompanyApplicationTests {

	@Test
	void contextLoads() {
	}

}
