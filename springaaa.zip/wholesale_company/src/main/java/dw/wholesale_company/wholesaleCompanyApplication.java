package dw.wholesale_company;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class wholesaleCompanyApplication {

	public static void main(String[] args) {
		SpringApplication.run(wholesaleCompanyApplication.class, args);
	}

}
