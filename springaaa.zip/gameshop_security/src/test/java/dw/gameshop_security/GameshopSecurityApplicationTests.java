package dw.gameshop_security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GameshopSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
